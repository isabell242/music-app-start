import { formatTime } from "@/utils/player/time";
import Silde from "@/presentationals/player/Slider";
import { ChangeEvent } from "react";

interface Props {
  duration: number;
  currentTime: number;
  onChange: (seconds: number) => void;
}

export default function ProgressBar({
  duration,
  currentTime,
  onChange,
}: Props) {
  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const seconds = Number(e.currentTarget.value);
    onChange(seconds);
  };

  return (
    <div className="flex items-center gap-x-17">
      <span>{formatTime(currentTime)}</span>
      <input type="range" onChange={handleChange} min={0} max={duration} />
      <span>{formatTime(duration)}</span>
    </div>
  );
}
