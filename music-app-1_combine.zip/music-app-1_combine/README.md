npm i -g pnpm@9.7.1
(강사컴터는그랬음-관리자버전으로 실행해야함 sudo)

nodemodules, package.lock.json 삭제 후

pnpm install(터미널에서)

====================================

(클라이언트에서도 마찬가지)
npm i -g pnpm@9.7.1
(강사컴터는그랬음-관리자버전으로 실행해야함 sudo)

nodemodules, package.lock.json 삭제 후

pnpm install(터미널에서)

===================================
pnpm dev




<모노레프로 통합-공통파일만드는과정-music-client폴더내 파일에 해야함!>
새로 cmd 열고 클라이언트와 서버를 함께 관리 할 수 있는 프로젝트 생성
mkdir music-app && cd music-app 

pnpm init

mkdir packages

move ../music-client packages
move ../music-server packages

code .

pnpm-workspace.yaml 파일 만들어서

pnpm install (workspace를 만들어야함)

pnpm --filter=music-server dev

pnpm --filter=music-client i -D tailwindcss@3.4.3 postcss@8.4.39 autoprefixer@10.4.9

cd packages/music-client

pnpm tailwindcss init -p

tailwind.config.js파일에서 
/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {},
  },
  plugins: [],
};

index.css파일에서 
@tailwind base;
@tailwind components;
@tailwind utilities;

body {
  margin: 0;
  display: flex;
  min-height: 100vh;
}

pnpm --filter=music-client dev

pnpm i @tanstack/react-query@5.29.2 graphql@16.8.1 graphql-request@7.1.0

.env.local파일만든후,
VITE_API_HOST=http://localhost:4000

vite-env.d.ts파일에 
/// <reference types="vite/client" />

interface ImportMetaEnv {
  VITE_API_HOST: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

graphqlClient.ts파일에 
import { GraphQLClient } from "graphql-request";

const endpoint = import.meta.env.VITE_API_HOST;

export const graphqlClient = new GraphQLClient(endpoint);

tsconfig.json파일에 linting 밑에 작성하기
/* Linting */
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,

    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"]
    }

vite.config.ts파일에 
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": "/src",
    },
  },
});
=============================================================















# React + TypeScript + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## Expanding the ESLint configuration

If you are developing a production application, we recommend updating the configuration to enable type aware lint rules:

- Configure the top-level `parserOptions` property like this:

```js
export default {
  // other rules...
  parserOptions: {
    ecmaVersion: 'latest',
    sourceType: 'module',
    project: ['./tsconfig.json', './tsconfig.node.json'],
    tsconfigRootDir: __dirname,
  },
}
```

- Replace `plugin:@typescript-eslint/recommended` to `plugin:@typescript-eslint/recommended-type-checked` or `plugin:@typescript-eslint/strict-type-checked`
- Optionally add `plugin:@typescript-eslint/stylistic-type-checked`
- Install [eslint-plugin-react](https://github.com/jsx-eslint/eslint-plugin-react) and add `plugin:react/recommended` & `plugin:react/jsx-runtime` to the `extends` list
