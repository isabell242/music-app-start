function App() {
  return <div className="bg-red-100 w-full h-full"></div>;
}

export default App;
