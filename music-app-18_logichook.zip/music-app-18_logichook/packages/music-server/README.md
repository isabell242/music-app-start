npm i -g pnpm@9.7.1
(강사컴터는그랬음-관리자버전으로 실행해야함 sudo)

nodemodules, package.lock.json 삭제 후

pnpm install(터미널에서)

====================================

(클라이언트에서도 마찬가지)
npm i -g pnpm@9.7.1
(강사컴터는그랬음-관리자버전으로 실행해야함 sudo)

nodemodules, package.lock.json 삭제 후

pnpm install(터미널에서)

===================================
pnpm dev
