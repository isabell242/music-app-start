import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import useGetSongs from "./hooks/useGetSongs";
import { ErrorBoundary } from "react-error-boundary";
import ErrorFallback from "./presentationals/common/ErrorFallback";
import RootLayout from "./presentationals/common/RootLayout";
import SongCard from "./presentationals/common/SongCard";
import SliderPanel from "./common/SilderPanel";
import SectionPanel from "./home/SectionPanel";
import PlayerWrapper from "./player/PlayerWrapper";
import { useState } from "react";
import AudioContainer from "@/containers/player/AudioContainer";
import PlaylistContainer from "@/containers/home/PlaylistContainer";

const queryClient = new QueryClient();

function App() {
  const { isPlayListExpanded, currentSong } = useAppStore();

  return (
    <QueryClientProvider client={queryClient}>
      <RootLayout>
        <ErrorBoundary FallbackComponent={ErrorFallback}>
          <TempComponent />
        </ErrorBoundary>
        <SliderPanel open={isPlayListExpanded}>
          <PlaylistContainer />
        </SliderPanel>
      </RootLayout>
      <PlayerWrapper>
        <AudioContainer src={currentSong?.path} />
      </PlayerWrapper>
    </QueryClientProvider>
  );
}

// function TempComponent() {
//   const { data } = useGetSongs();

//   return (
//     <Section>
//       <Section.Title>패캠을 위한 믹스 & 추천</Section.Title>
//       <Section.Content>
//         <div className="flex gap-x-18">
//           {data?.map((song) => (
//             <SongCard key={song.id} variant="vertical" className="shrink-0">
//               <SongCard.Image
//                 src={"https://via.placeholder.com/150"}
//                 alt={song.title}
//               />
//               <SongCard.Content>
//                 <SongCard.Title>{song.title}</SongCard.Title>
//                 <SongCard.Description>{song.artist}</SongCard.Description>
//               </SongCard.Content>
//             </SongCard>
//           ))}
//         </div>
//       </Section.Content>
//     </Section>
//   );
// }

function TempComponent() {
  const { data } = useGetSongs();
  const { addToPlaylist } = useAppStore();
  return (
    <SectionPanel
      songs={data ?? []}
      moreLink="/"
      title="패캠을 위한 믹스 추천"
      onItemClick={(song) => addToPlaylist(song)}
    />
  );
}

export default App;
